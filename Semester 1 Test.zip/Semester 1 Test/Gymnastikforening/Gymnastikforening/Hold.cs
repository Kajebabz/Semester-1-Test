﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gymnastikforening
{
    public class Hold
    {
        private List<Deltager> deltagerList;


        public Hold()
        {
        }

        public Hold(string holdId, string holdNavn, double prisPrDeltager, int maxAntalBørn)
        {
            deltagerList = new List<Deltager>();
            HoldId = holdId;
            HoldNavn = holdNavn;
            PrisPrDeltager = prisPrDeltager;
            MaxAntalBørn = maxAntalBørn;
        }

        public string HoldId { get; set; }
        public string HoldNavn { get; set; }
        public double PrisPrDeltager { get; set; }   
        public int MaxAntalBørn { get; set; }

        public int AntalTilmeldte()
        {
            int AntalTilmeldteBørn = 0;
            foreach (Deltager deltageneBørn in deltagerList)
            {
                AntalTilmeldteBørn = AntalTilmeldteBørn + deltageneBørn.AntalBørn;
            }
            Console.WriteLine($"Antal tilmeldte børn: {AntalTilmeldteBørn}");
            return AntalTilmeldteBørn;
        }

        // Mangler lidt arbejde.

        //public void TilmeldDeltager2(Deltager deltager)
        //{
        //    int i = 0;
        //    foreach (Deltager deltag in deltagerList)
        //    {
        //        i = i + deltag.AntalBørn;
        //    }

        //    if (MaxAntalBørn <= i + deltager.AntalBørn)
        //    {
        //        Console.WriteLine($"Deltager tilmeldt!");
        //        deltagerList.Add(deltager);
        //    }
        //    Console.WriteLine("Holdet er desværre fyldt!");
        //}

        public void TilmeldDeltager(Deltager deltager)
        {
            Console.WriteLine($"Deltager tilmeldt!");
            deltagerList.Add(deltager);
        }

        public override string ToString()
        {
            return $"{nameof(HoldId)}={HoldId.ToString()}, {nameof(HoldNavn)}={HoldNavn}, {nameof(PrisPrDeltager)}={PrisPrDeltager.ToString()}, {nameof(MaxAntalBørn)}={MaxAntalBørn.ToString()}";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Gymnastikforening
{
    public class HoldCatalog
    {
        private List<Hold> Holds;

        public HoldCatalog()
        {
            Holds = new List<Hold>();
        }

        public void AddHold(Hold hold)
        {
            foreach (Hold H in Holds) 
            {
                if (hold.HoldId == H.HoldId)
                {
                    throw new ArgumentException($"Kan ikke tilføje hold da der allerede findes et {hold.HoldId}");
                }
            }
            Holds.Add(hold);
            Console.WriteLine($"Tilføjet nyt Hold til listen!");
        }

        public Hold FindHold(string HoldId)
        {
            foreach (Hold hold in Holds)
            {
                if (hold.HoldId == HoldId)
                {
                    Console.WriteLine($"Hold fundet! : {hold}");
                    return hold;
                }
            }
            Console.WriteLine("Intet hold fundet med den ID");
            return null;
        }

        public override string ToString()
        {
            string meh = $"Alle Hold:\n";
            foreach (var meh1 in Holds)
            {
                meh += meh1.ToString() + "\n";

            }

            return meh;
        }
    }
}

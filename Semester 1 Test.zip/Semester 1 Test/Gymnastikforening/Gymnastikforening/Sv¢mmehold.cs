﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gymnastikforening
{
    public class Svømmehold : Hold
    {
        public Svømmehold() : base()
        {
        }

        public Svømmehold(string holdId, string holdNavn, double prisPrDeltager, int maxAntalBørn, string svømmeHal) : base(holdId, holdNavn, prisPrDeltager, maxAntalBørn)
        {
            SvømmeHal = svømmeHal;
        }

        public string SvømmeHal { get; set; }

        public override string ToString()
        {
            return $"{nameof(HoldId)}={HoldId}, {nameof(HoldNavn)}={HoldNavn}, {nameof(PrisPrDeltager)}={PrisPrDeltager.ToString()}, {nameof(MaxAntalBørn)}={MaxAntalBørn.ToString()}, {nameof(SvømmeHal)}={SvømmeHal}";
        }
    }
}

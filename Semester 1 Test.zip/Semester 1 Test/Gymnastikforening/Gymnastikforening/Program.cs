﻿
using Gymnastikforening;

// Opretter instanser af Hold
Hold hold1 = new Hold("TumleE22", "Musik for tumlinger", 500, 15);
Hold hold2 = new Hold("SpringF21", "Spring for de mindste", 750, 20);
Hold hold3 = new Hold("DansGladV20", "Dans dig glad", 300, 30);
Hold hold4 = new Hold("LegMedBoldV22", "Gulv lege med bold", 450, 18);

// Udskriver hver instans
Console.WriteLine(hold1);
Console.WriteLine(hold2);
Console.WriteLine(hold3);

HoldCatalog HoldCata = new HoldCatalog();

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

// Tilføjer til listen
HoldCata.AddHold(hold1);
HoldCata.AddHold(hold2);
HoldCata.AddHold(hold3);

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

// Leder efter hold baseret på ID
HoldCata.FindHold("SpringF21"); // Gyldig
HoldCata.FindHold("HesteHopS22"); // Ugyldig

Console.WriteLine();

// Viser alle hold ved at anvende ToString() fra HoldCatalog
Console.WriteLine(HoldCata);

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

// Deltager !!

Deltager deltager1 = new Deltager("Joachim Petersen", "Gartnervang 24, Roskilde, 4000 Roskilde", 3);
Deltager deltager2 = new Deltager("Maria skovsen", "Musicon 24, Roskilde, 4000 Roskilde", 1);
Deltager deltager3 = new Deltager("Henriette knudsen", "Grønager 18, Gevninge, 4000 Roskilde", 4);

Console.WriteLine(deltager1);
Console.WriteLine(deltager2);
Console.WriteLine(deltager3);

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

// Kan tilmelde til hold og kan vise antaltilmeldte på hold. Mangler at kunne vise om der er plads.

hold1.TilmeldDeltager(deltager3);
hold1.TilmeldDeltager(deltager3);
hold1.TilmeldDeltager(deltager3);
//hold1.TilmeldDeltager2(deltager2); <- Mangler lidt arbejde.

hold1.AntalTilmeldte();

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

Console.WriteLine("EXCEPTIONS");
Console.WriteLine();
// Tilfølger hold4
try
{
    HoldCata.AddHold(hold4);
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

// Prøver at tilfølge hold4 (igen)
try
{
    HoldCata.AddHold(hold4);
}
catch (Exception ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine();
Console.WriteLine("-------------------------------------------------------------------------------------");
Console.WriteLine();

// SVØMMEHOL

Svømmehold svømmehold1 = new Svømmehold("SvømE22", "Svømning for de mindste", 625, 15, "RoskildeSvømmeHal");
Svømmehold svømmehold2 = new Svømmehold("SvømV21", "Leg i vandet", 450, 12, "RoskildeSvømmeHal");
Svømmehold svømmehold3 = new Svømmehold("SvømS22", "Lær vandet at kende", 375, 20, "RoskildeSvømmeHal");

Console.WriteLine(svømmehold1);
Console.WriteLine(svømmehold2);
Console.WriteLine(svømmehold3);

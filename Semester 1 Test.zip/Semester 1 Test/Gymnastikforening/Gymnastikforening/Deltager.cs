﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gymnastikforening
{
    public class Deltager
    {
        public Deltager()
        {
        }

        public Deltager(string forældreNavn, string address, int antalBørn)
        {
            ForældreNavn = forældreNavn;
            Address = address;
            AntalBørn = antalBørn;
        }

        public string ForældreNavn { get; set; }
        public string Address { get; set; }
        public int AntalBørn { get; set; }

        public override string ToString()
        {
            return $"{nameof(ForældreNavn)}={ForældreNavn}, {nameof(Address)}={Address}, {nameof(AntalBørn)}={AntalBørn.ToString()}";
        }
    }
}
